﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Evaluation;
using BioDataAnalyzer.Data;

namespace BioDataEvaluator
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] userDataFiles = { "s008_m21_Force\\s008_m21_",
                            "s001_m22_Force\\s001_m22_",
                            "s009_m22_Force\\s009_m22_",
                            "s010_m22_Force\\s010_m22_",
                            "s002_m25_Force\\s002_m25_",
                            "s006_m25_Force\\s006_m25_",
                            "s007_m25_Force\\s007_m25_",
                            "s003_m27_Force\\s003_m27_",
                            "s005_m28_Force\\s005_m28_",
                            "s004_m30_Force\\s004_m30_" };
            string[] userDataLabels = { "m21_1", "m22_1", "m22_2", "m22_3", "m25_1", "m25_2", "m25_3", "m27_1", "m28_1", "m30_1" };
            string rootPath = "D:\\Thesis\\Data";

            DatasetReader dsDelimitedReader = new DatasetReader(new KistlerFootstepExtractor(15, 15, 100, 2, 5, 6, 7, 8)); // ignore 1st calibration step, only monitor on z-force records

            for (int i = 0; i < userDataFiles.Length; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    dsDelimitedReader.AddDelimitedFileSample(rootPath + "\\" + userDataFiles[i] + "Asics_walk_" + j.ToString() + ".anc", userDataLabels[i], "\t", startLine : 12, timeColumn : 0);
                }
            }

            SampleSet<Sample> dsDelimitedSampleSet = dsDelimitedReader.GetSampleSet();
            SampleSet<Sample> areaSamples = dsDelimitedSampleSet.ApplySampleExtractor(new AreaSetExtractor(500));
            SampleSet<Sample> derivativeSamples = areaSamples.ApplyTransformation(new DerivativeTransform());
            //SampleSet<Sample> pointSamples = dsDelimitedSampleSet.ApplySampleExtractor(new PointSetExtractor(2000));
            SampleSet<Sample> magnitudeSamples = derivativeSamples.ApplyTransformation(new MagnitudeSpectrumTransform());
            SampleSet<Sample> powerSpectrumSamples = derivativeSamples.ApplyTransformation(new PowerSpectrumTransform());
            areaSamples = dsDelimitedSampleSet.ApplySampleExtractor(new AreaSetExtractor(512));
            SampleSet<Sample> waveletSamples = areaSamples.ApplyTransformation(new OptimalWaveletPacketTransform(areaSamples, new Coif06(), 4, 0.3));

            LLSRNormalizer llsr = new LLSRNormalizer(areaSamples);
            SampleSet<Sample> llsrNormalizedSamples = areaSamples.ApplyTransformation(llsr);

            LLSRDTWNormalizer llsrdtw = new LLSRDTWNormalizer(areaSamples, 0.09);
            SampleSet<Sample> llsrdtwNormalizedSamples = areaSamples.ApplyTransformation(llsrdtw);

            System.IO.StreamWriter file = new System.IO.StreamWriter("C:\\Users\\jemason\\Documents\\llsrdtwslopestemplates.csv");
            for (int i = 0; i < llsrdtw.AmplitudeSlopes[4].Length; i++)
            {
                file.WriteLine(llsrdtw.Templates[4][i] + "," + llsrdtw.AmplitudeSlopes[4][i] + "," + llsrdtw.PhaseSlopes[4][i]);
            }
            file.Close();

            /*Dictionary<int, List<double[]>> alignedSamples = LLSRDTWNormalizer.FindApproximateDTWAlignment(areaSamples, 0.09);

            System.IO.StreamWriter file = new System.IO.StreamWriter("C:\\Users\\jemason\\Documents\\alignedsamples.csv");
            // TODO - fix this so different samples show up beside each other
            for (int j = 0; j < alignedSamples[5][0].Length; j++)
            {
                string dataRow = "";
                for (int i = 0; i < alignedSamples[5].Count; i++)
                {
                    dataRow += alignedSamples[5][i][j] + ",";
                }
                file.WriteLine(dataRow);
            }

            file.Close(); */

            areaSamples[1].SaveAsCSV("C:\\Users\\jemason\\Documents\\area1.csv");
            //derivativeSamples[0].SaveAsCSV("C:\\Users\\jemason\\Documents\\derivative.csv");
            //magnitudeSamples[0].SaveAsCSV("C:\\Users\\jemason\\Documents\\magnitude.csv");
            //powerSpectrumSamples[0].SaveAsCSV("C:\\Users\\jemason\\Documents\\psd.csv");
            //waveletSamples[0].SaveAsCSV("C:\\Users\\jemason\\Documents\\wavelet.csv");
            llsrNormalizedSamples[1].SaveAsCSV("C:\\Users\\jemason\\Documents\\llsr1.csv");
            llsrdtwNormalizedSamples[1].SaveAsCSV("C:\\Users\\jemason\\Documents\\llsrdtw1.csv");

            //Evaluator.Evaluate<Sample>(dsDelimitedReader.GetSampleSet(), null, 5);


            //Evaluator.Evaluate<CrossValidatedSample>(null, null, 5);

            string matRootPath = "D:\\Book\\SFootBD\\SFootBD\\SFootBD";

            string matDataFile = matRootPath + "\\2008-08-04_09-51-44_040.mat";

            DatasetReader dsMatReader = new DatasetReader(new ATVSExtractor());

            dsMatReader.AddMatlabFileSample(matDataFile, "15", "dataR", interval: 0.000625);

            SampleSet<Sample> subset = dsMatReader.GetSampleSet().GenerateSampleSubsets(new SampleGRFExtractor(), new SampleAverageExtractor(), new SampleMaximumContourExtractor(), new SampleMinimumContourExtractor());

            // calculate GRF (integrating each sensor signal across time, and then summation of 88 single profiles to provide global GRF)

            // average 88 sensors of array to produce a single profile

            // calculate upper contour of the signal (maxima of sensor for each time sample)

            // calculate lower contour of the signal (minima of sensor for each time sample)

            Sample sample = subset.AsSampleList()[0];
            //sample.SaveAsCSV("C:\\Users\\jemason\\Documents\\matsample.csv");

            sample = dsMatReader.GetSampleSet()[0];
            //sample.SaveAsCSV("C:\\Users\\jemason\\Documents\\matsampledata.csv");



            Console.WriteLine("DONE");
        }
    }
}
