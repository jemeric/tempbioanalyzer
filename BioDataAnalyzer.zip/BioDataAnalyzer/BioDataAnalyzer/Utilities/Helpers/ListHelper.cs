﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;

namespace BioDataAnalyzer.Utilities.Helpers
{
    public class ListHelper
    {
        // count the number of distinct identifiers per sample
        public static int CountIdentifiers<T>(SampleSet<T> samples) where T : Sample
        {
            return samples.Select(x => x.GetIdentifier()).Distinct().Count();
        }

        public static List<Sample> GetCrossValidation(List<CrossValidatedSample> samples, int crossValidation)
        {
            return samples.Where(x => x.GetCrossValidation().Equals(crossValidation)).ToList().Cast<Sample>().ToList();
        }

        // get a list of all dinstinct identifiers
        public static List<String> GetIdentifiers(List<Sample> samples)
        {
            return samples.Select(x => x.GetIdentifier()).Distinct().ToList();
        }

        public static List<Sample> GetSamplesWithIdentifier(List<Sample> samples, string identifier)
        {
            List<Sample> identifierSamples = samples.Where(x => x.GetIdentifier().Equals(identifier)).ToList();
            identifierSamples.Sort(new Comparison<Sample>((s1, s2) => s1.GetOrder().CompareTo(s2))); // order samples by identifier
            return identifierSamples;
        }

    }

}
