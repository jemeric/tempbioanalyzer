﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public interface SampleVisitor<T>
    {
        T Accept(StandardSample sample);
        T Accept(CrossValidatedSample sample);
    }
}
