﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public abstract class DimensionalityReduction : Preprocessor
    {
        public Sample ApplyReduction(Sample sample)
        {
            return sample.AcceptVisitor(new SampleDataVisitor(GetReducedDimensions(sample), false));
        }

        protected List<Tuple<double, double[]>> GetReducedDimensions(Sample sample)
        {
            return Reduce(sample).Select((dimension, i) => new Tuple<double, double[]>(i, new double[] { dimension })).ToList();
        }

        protected abstract double[] Reduce(Sample sample);

        protected override Sample Process(Sample sample)
        {
            return ApplyReduction(sample);
        }
    }
}
