﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Accord.Statistics.Analysis;

namespace BioDataAnalyzer.Data
{
    public class PrincipalComponentAnalysisReduction : DimensionalityReduction, Trainable
    {
        protected int numberOfOutputs;
        protected AnalysisMethod method;
        protected PrincipalComponentAnalysis pca = null;

        protected PrincipalComponentAnalysisReduction(AnalysisMethod method, int numberOfOutputs, PrincipalComponentAnalysis pca)
        {
            this.method = method;
            this.numberOfOutputs = numberOfOutputs;
            this.pca = pca;
        }

        public PrincipalComponentAnalysisReduction(AnalysisMethod method, int numberOfOutputs)
        {
            this.numberOfOutputs = numberOfOutputs;
            this.method = method;
        }

        public bool IsTrained()
        {
            return pca != null;
        }

        public P Train<P>(List<Sample> trainingSamples) where P : Preprocessor
        {
            this.pca = new PrincipalComponentAnalysis((PrincipalComponentMethod)method, numberOfOutputs: numberOfOutputs, whiten: true);

            double[][] data = trainingSamples.Select(sample => sample.GetDimensions()).ToArray();
            pca.Learn(data);

            //test.Eigenvalues = new double[];  - * TODO for serializing saved PCA
            //test.ComponentVectors = new double[];

            return this as P;
        }

        protected override double[] Reduce(Sample sample)
        {
            return pca.Transform(sample.GetDimensions());
        }

        public override Preprocessor Copy()
        {
            return new PrincipalComponentAnalysisReduction(method, numberOfOutputs, pca);
        }
    }

    public enum AnalysisMethod
    {
        Covariance = PrincipalComponentMethod.Center, // formerly Accord AnalysisMethod.Covariance
        Correlation = PrincipalComponentMethod.Standardize // formerly Accord AnalysisMethod.Correlation
    }
}
