﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public interface Trainable
    {
        bool IsTrained();
        P Train<P>(List<Sample> trainingSamples) where P : Preprocessor;
    }
}
