﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accord.Statistics.Models.Regression.Linear;

namespace BioDataAnalyzer.Data
{
    public class LLSRNormalizer : SampleTransform
    {
        protected int[] columns;
        protected double standardTime; // time to standardize to (the mean of the training set)
        protected int trainingRowCount;
        protected int trainingColumnCount;

        public Dictionary<int, double[]> AmplitudeSlopes { get; protected set; } // slopes marking the sample data amplitudes (DataRows) with respect to sample duration

        protected LLSRNormalizer() { /* for use in sub classes with different initial regression calculations */ }

        public LLSRNormalizer(SampleSet<Sample> trainingSet, params int[] columns)
        {
            InitializeTimeAndCountProperties(trainingSet, columns);
            Dictionary<int, List<RegressionColumn>> trainingRegressionColumns = GenerateRegressionColumns(trainingSet, trainingColumnCount);
            Regressor regressor = GenerateRegressionSlopes<RegressionColumn, Regressor>(trainingRegressionColumns);
            AmplitudeSlopes = regressor.GetAmplitudeSlopes();
        }

        protected void InitializeTimeAndCountProperties(SampleSet<Sample> trainingSet, int[] columns)
        {
            List<int> trainingRows = trainingSet.Select(sample => sample.GetDataRows().Count).Distinct().ToList();
            if (trainingRows.Count != 1)
            {
                throw new ArgumentException("All training samples must be the same length");
            }
            trainingRowCount = trainingRows[0];
            trainingColumnCount = trainingSet[0].GetColumnCount();
            this.columns = GetAppliedColumns(columns, trainingSet[0].GetColumnCount()); // default to applying to all columns if no particular column provided
            this.standardTime = trainingSet.Select(sample => sample.GetDuration().Value).Average();
        }

        private Dictionary<int, List<RegressionColumn>> GenerateRegressionColumns(List<Sample> trainingSet, int trainingColumnCount)
        {
            // convert sample list to regression list organized by column
            return Enumerable.Range(0, trainingColumnCount)
                .Select(index => new { index, columns = trainingSet.Select(sample => new RegressionColumn(sample.GetDataRows(index), sample.GetIdentifier(), sample.GetDuration().Value)).ToList() })
                .ToDictionary(s => s.index, s => s.columns);
        }

        protected Dictionary<string, T> GetMinimumDurationColumnSample<T>(List<T> trainingColumnSamples) where T : RegressionColumn
        {
            // get the minimum duration regression column (grouped by identifier)
            return trainingColumnSamples.GroupBy(columnSample => columnSample.Identifier, columnSample => columnSample)
                .Select(columnList => columnList.Aggregate((currentMin, next) => (currentMin == null || next.Duration < currentMin.Duration ? next : currentMin))) // minimum duration column
                .ToDictionary(column => column.Identifier, column => column);
        }

        /**
         * Return calibrated column
         * 
         */
        protected List<T> GenerateCalibratedColumnSamples<T>(List<T> trainingColumnSamples) where T : RegressionColumn
        {
            // get each minimum duration sample grouped by identifier
            Dictionary<string, T> minimumDurationRegressionColumns = GetMinimumDurationColumnSample(trainingColumnSamples);

            // get the samples with each data entry shifted with respect to the sample with the minimum duration for each identifier
            return trainingColumnSamples.Select(columnSample => columnSample.ApplyCalibration(minimumDurationRegressionColumns[columnSample.Identifier])).ToList();
        }

        protected R GenerateRegressionSlopes<T, R>(Dictionary<int, List<T>> trainingRegressionColumns) where T : RegressionColumn where R : Regressor, new()
        {
            R regressor = new R();
            // for each column calibrate the data and regress
            Parallel.For(0, trainingColumnCount, (i, alignedIndices) =>
            {
                // calibration - for each identifier set the point at the minimum time to (0, 0) and standardize other points around it
                List<T> calibratedSet = GenerateCalibratedColumnSamples(trainingRegressionColumns[i]);

                regressor.AddColumnRegression<T>(i, calibratedSet);
            });

            return regressor;
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            if (!sample.GetDuration().HasValue)
            {
                throw new ArgumentException("Sample does not have duration");
            }
            // normalize applicable columns
            double normConst = (standardTime / sample.GetDuration().Value);
            List<Tuple<double, double[]>> normalizedData = TransformData(sample, (value, i, j) => value + AmplitudeSlopes[j][i] * (standardTime - sample.GetDuration().Value), columns);
            // normalize the time interval
            return normalizedData.Select((value, i) => new Tuple<double, double[]>(i * (standardTime / normalizedData.Count), value.Item2)).ToList();
        }

        protected override int[] GetColumns()
        {
            return columns;
        }

        protected override bool RecalculateDuration()
        {
            return true; // regression transforms each sample into similar time domain (the mean)
        }
    }

     /**
     * Class representing the aligned rows/indices in a column
     * 
     */
    public class RegressionColumn
    {
        public string Identifier { get; private set; }
        public double Duration { get; private set; }
        protected double[] rows;
        public RegressionColumn(double[] rows, string identifier, double duration)
        {
            this.rows = rows;
            Identifier = identifier;
            Duration = duration;
        }
        public virtual T ApplyCalibration<T>(T calibrationSample) where T : RegressionColumn
        {
            // calibrate column amplitude
            double[] calibratedRows = GetCalibratedRows(calibrationSample);
            return new RegressionColumn(calibratedRows, Identifier, Duration) as T;
        }
        protected double[] GetCalibratedRows<T>(T calibrationSample) where T : RegressionColumn
        {
            return rows.Select((r, i) => r - calibrationSample.rows[i]).ToArray();
        }
        public virtual double[] GetRows()
        {
            return rows;
        }
    }

    /**
     * Class representing the regression to be performed
     */
    public class Regressor
    {
        Dictionary<int, double[]> amplitudeSlopesByColumn = new Dictionary<int,double[]>();
        public virtual void AddColumnRegression<T>(int column, List<T> calibratedSet) where T : RegressionColumn
        {
            // take the regression with all points per user standardized around a minimum of (0, 0) (all we care about is the slope anyway)
            // group by row index for row-based regression
            double[] amplitudeSlopes = calibratedSet.SelectMany(calibratedColumn => calibratedColumn.GetRows().Select((row, rowIndex) => new { rowIndex, duration = calibratedColumn.Duration, value = row }))
                .GroupBy(r => r.rowIndex, r => new { duration = r.duration, value = r.value })
                .Select(r => GenerateRegression(r.Select(d => d.duration).ToArray(), r.Select(v => v.value).ToArray())).ToArray();

            amplitudeSlopesByColumn.Add(column, amplitudeSlopes);
        }

        public Dictionary<int, double[]> GetAmplitudeSlopes()
        {
            return amplitudeSlopesByColumn; // column => slopes
        }

        protected double GenerateRegression(double[] x, double[] y)
        {
            OrdinaryLeastSquares ols = new OrdinaryLeastSquares();
            SimpleLinearRegression regression = ols.Learn(x, y);
            return regression.Slope;
        }

    }

}
