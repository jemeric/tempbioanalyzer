﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class LinfNormalizer : SampleTransform
    {
        private int[] columns;

        public LinfNormalizer(params int[] columns)
        {
            this.columns = columns;
        }

        protected double GetMaximumAmplitude(Sample sample, int[] columns)
        {
            return sample.GetAllValuesForColumns(columns).Select(value => Math.Abs(value)).Max();
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            return TransformData(sample, value => value / GetMaximumAmplitude(sample, columns), columns);
        }

        protected override int[] GetColumns()
        {
            return columns;
        }

        protected override bool RecalculateDuration()
        {
            return false;
        }

        public override Preprocessor Copy()
        {
            return new LinfNormalizer(columns);
        }
    }
}
