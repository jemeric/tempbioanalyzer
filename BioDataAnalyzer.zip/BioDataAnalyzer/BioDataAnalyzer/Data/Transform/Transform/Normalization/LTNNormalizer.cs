﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data.Transform.Transform.Normalization
{
    public class LTNNormalizer : SampleTransform
    {
        private int[] columns;
        private double standardTime; // time to standardize to (note this will just scale according to the standard time - may only make sense records that are a factor of time such as area)

        // be warned this alters the sample duration and time intervals
        public LTNNormalizer(double standardTime, params int[] columns)
        {
            this.columns = columns;
            this.standardTime = standardTime;
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            if (!sample.GetDuration().HasValue)
            {
                throw new ArgumentException("Sample does not have duration");
            }
            // normalize applicable columns
            double normConst = (standardTime / sample.GetDuration().Value);
            List<Tuple<double, double[]>> normalizedData = TransformData(sample, value => value * normConst, columns);
            // normalize the time interval
            return normalizedData.Select((value, i) => new Tuple<double, double[]>(i * (standardTime / normalizedData.Count), value.Item2)).ToList();
        }

        protected override int[] GetColumns()
        {
            return this.columns;
        }

        protected override bool RecalculateDuration()
        {
            return true;
        }
    }
}
