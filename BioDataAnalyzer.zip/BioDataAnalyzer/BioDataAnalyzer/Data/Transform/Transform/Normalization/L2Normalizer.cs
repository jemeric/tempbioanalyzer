﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class L2Normalizer : SampleTransform
    {
        private int[] columns;

        public L2Normalizer(params int[] columns)
        {
            this.columns = columns;
        }

        protected double GetEuclideanDistance(Sample sample, int[] columns) 
        {
            return Math.Sqrt(sample.GetAllValuesForColumns(columns).Sum(value => Math.Pow(value, 2)));
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            return TransformData(sample, value => value / GetEuclideanDistance(sample, columns), columns);
        }

        protected override int[] GetColumns()
        {
            return columns;
        }

        protected override bool RecalculateDuration()
        {
            return false;
        }

        public override Preprocessor Copy()
        {
            return new L2Normalizer(columns);
        }
    }
}
