﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class L1Normalizer : SampleTransform
    {
        private int[] columns;

        public L1Normalizer(params int[] columns)
        {
            this.columns = columns;
        }

        protected double GetAbsoluteSum(Sample sample, int[] columns)
        {
            return sample.GetAllValuesForColumns(columns).Sum(value => Math.Abs(value)); // sum the absolute value of each column value
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            return TransformData(sample, value => value / GetAbsoluteSum(sample, columns), columns);
        }

        protected override int[] GetColumns()
        {
            return columns;
        }

        protected override bool RecalculateDuration()
        {
            return false;
        }
    }
}
