﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class OptimalWaveletPacketTransform : WaveletPacketTransform
    {
        private int[] columns;
        private int toLevel;
        private Wavelet wavelet;
        private List<WaveletSubspace>[] optimalSubspace;
        private int trainingColumnCount;
        private int trainingRowCount;
        private double r;

        public OptimalWaveletPacketTransform(SampleSet<Sample> trainingSet, Wavelet wavelet, int toLevel, double r, params int[] columns)
        {
            List<int> trainingRows = trainingSet.Select(sample => sample.GetDataRows().Count).Distinct().ToList();
            if (trainingRows.Count != 1)
            {
                throw new ArgumentException("All training samples must be the same length");
            }
            trainingRowCount = trainingRows[0];
            this.columns = GetAppliedColumns(columns, trainingSet[0].GetColumnCount()); // default to applying to all columns if no particular column provided
            this.toLevel = toLevel;
            this.wavelet = wavelet;
            this.r = r;
            trainingColumnCount = trainingSet[0].GetColumnCount();
            optimalSubspace = GenerateOptimalWaveletPacketDecomposition(trainingSet);
        }

        protected List<WaveletSubspace>[] GenerateOptimalWaveletPacketDecomposition(SampleSet<Sample> trainingSet)
        {
            List<WaveletSubspace>[] columnOptimalSubspaces = new List<WaveletSubspace>[columns.Length];
            for (int j = 0; j < trainingColumnCount; j++)
            {
                // only need to calculate optimal decomposition for applicable columns
                if (columns.Contains(j))
                {
                    columnOptimalSubspaces[j] = GetColumnOptimalWaveletPacketDecomposition(trainingSet, j);
                }
            }
            return columnOptimalSubspaces;
        }

        protected List<WaveletSubspace> GetColumnOptimalWaveletPacketDecomposition(SampleSet<Sample> trainingSet, int column)
        {
            // perform the wavelet packet decomposition of the data rows for the given column
            List<WaveletPacket> packetList = trainingSet.Select(sample => GetWaveletPacketDecomposition(sample, column, wavelet, toLevel)).ToList();

            // calculate the optimal wavelet packet decomposition using a fuzzy membership function criterion
            FuzzySet fcmTop = new FuzzySet(packetList, r);
            return fcmTop.GetOptimalSubspaceList();
        }

        protected override List<Tuple<double, double[]>> GetTransformedRows(Sample sample, int[] columns)
        {
            if (sample.GetDataRows().Count != trainingRowCount)
            {
                throw new ArgumentException("Sample must match the length of the training samples");
            }

            // transform each applicable column with optimal wavelet packet decomposition
            double[][] transformedColumns = new double[trainingColumnCount][];
            for (int j = 0; j < trainingColumnCount; j++)
            {
                // only need to calculate optimal decomposition for applicable columns
                if (columns.Contains(j))
                {
                    WaveletPacket top = GetWaveletPacketDecomposition(sample, j, wavelet, toLevel);
                    transformedColumns[j] = optimalSubspace[j].Select(subspace => top.FindSubspace(subspace)).SelectMany(packet => packet.Coefficients).ToArray();
                }
                else
                {
                    transformedColumns[j] = sample.GetDataRows(j);
                }
            }
            List<Tuple<double, double[]>> waveletData = new List<Tuple<double, double[]>>();
            for (int row = 0; row < trainingRowCount; row++)
            {
                waveletData.Add(new Tuple<double, double[]>(sample.GetDataRows()[row].Item1, transformedColumns.Select(coefficientList => coefficientList[row]).ToArray()));
            }
            return waveletData;
        }
        
        protected override int[] GetColumns()
        {
            return columns;
        }

        protected override bool RecalculateDuration()
        {
            return false;
        }
    }
}
