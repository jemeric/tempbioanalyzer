﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class WaveletSubspace
    {
        public int DecompositionLevel { get; private set; }
        public int SubspaceIndex { get; private set; }

        public WaveletSubspace(int decompositionLevel, int subspaceIndex)
        {
            this.DecompositionLevel = decompositionLevel;
            this.SubspaceIndex = subspaceIndex;
        }
    }
}
