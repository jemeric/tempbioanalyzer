﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public interface Sample
    {
        string GetIdentifier();

        int GetOrder();

        List<Tuple<double, double[]>> GetDataRows();

        int GetColumnCount();

        double[] GetDataRows(int column);

        double[] GetDimensions();

        int GetDimensionCount();

        double[] GetIntervals();

        double? GetDuration();

        T AcceptVisitor<T>(SampleVisitor<T> visitor);

        void SaveAsCSV(String fileName);

        double[] GetAllValuesForColumns(int[] columns);
    }
}
