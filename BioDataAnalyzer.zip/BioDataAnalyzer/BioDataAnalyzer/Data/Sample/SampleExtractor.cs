﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public abstract class SampleExtractor : Preprocessor
    {
        public Sample Extract(Sample sample)
        {
            return sample.AcceptVisitor<Sample>(new SampleDataVisitor(ExtractRows(sample), RecalculateDuration()));
        }

        protected abstract List<Tuple<double, double[]>> ExtractRows(Sample sample);

        protected abstract bool RecalculateDuration();

        protected override Sample Process(Sample sample)
        {
            return this.Extract(sample);
        }
    }
}
