﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class ATVSExtractor : SampleExtractor
    {
        protected override List<Tuple<double, double[]>> ExtractRows(Sample sample)
        {
            List<Tuple<double, double[]>> atvsRows = new List<Tuple<double, double[]>>();
            foreach (Tuple<double, double[]> row in sample.GetDataRows())
            {
                if (row.Item2.Where(column => Math.Abs(column) > 0).Count() > 0)
                {
                    atvsRows.Add(row);
                }
                else
                {
                    break; // don't continue past the point where no rows have pressure readings
                }
            }
            return atvsRows;
        }

        protected override bool RecalculateDuration()
        {
            return true;
        }

        public override Preprocessor Copy()
        {
            return new ATVSExtractor();
        }
    }
}
