﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class CrossValidatedSample : StandardSample
    {
        private int crossValidation;

        public CrossValidatedSample(string identifier, List<Tuple<double, double[]>> dataRows, int order, int crossValidation, bool hasDuration) :
            this(identifier, dataRows, order, crossValidation, CalculateDuration(dataRows, hasDuration))
        {

        }

        public CrossValidatedSample(string identifier, List<Tuple<double, double[]>> dataRows, int order, int crossValidation, double? duration)
            : base(identifier, dataRows, order, duration)
        {
            if(crossValidation < 0) 
            {
                throw new ArgumentException("Cross Validation must be a number greater than 0");
            }
            this.crossValidation = crossValidation;
        }

        public int GetCrossValidation()
        {
            return crossValidation;
        }

        public override T AcceptVisitor<T>(SampleVisitor<T> visitor)
        {
            return visitor.Accept(this);
        }
    }
}
