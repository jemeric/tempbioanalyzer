﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class StandardSample : Sample
    {
        private string identifier; // unique identifier (owner of the sample)
        private int order; // sequential number of the sample (i.e. trail #) 
        private int columnCount; // the number of columns in each data row
        private List<Tuple<double, double[]>> dataRows; // <interval, data>
        private double? duration;

        public StandardSample(string identifier, List<Tuple<double, double[]>> dataRows, int order, bool hasDuration) :
            this(identifier, dataRows, order, CalculateDuration(dataRows, hasDuration))
        {

        }

        protected static double? CalculateDuration(List<Tuple<double, double[]>> dataRows, bool hasDuration)
        {
            // validate rows available
            if (dataRows.Count < 1)
            {
                throw new ArgumentException("A sample cannot have empty data rows");
            }
            double? timeDelta = dataRows.Last().Item1 - dataRows.First().Item1;
            return hasDuration ? timeDelta : null;
        }

        public StandardSample(string identifier, List<Tuple<double, double[]>> dataRows, int order, double? duration)
        {
            this.identifier = identifier;
            this.order = order;
            this.dataRows = dataRows;
            // validate rows available
            if (dataRows.Count < 1)
            {
                throw new ArgumentException("A sample cannot have empty data rows");
            }
            // validate columns per row
            List<int> columns = dataRows.Select(row => row.Item2.Length).Distinct().ToList();
            if (columns.Count > 1)
            {
                throw new ArgumentException("All sample rows must have the same number of columns");
            }
            columnCount = columns.DefaultIfEmpty(0).FirstOrDefault();
            this.duration = duration;
        }

        public string GetIdentifier()
        {
            return identifier;
        }

        public int GetOrder()
        {
            return order;
        }

        public List<Tuple<double, double[]>> GetDataRows()
        {
            return dataRows;
        }

        public int GetColumnCount()
        {
            return columnCount;
        }

        public double[] GetDataRows(int column)
        {
            return dataRows.Select(row => row.Item2[column]).ToArray();
        }

        public double[] GetDimensions()
        {
            return dataRows.Select(row => row.Item2).SelectMany(i => i).ToArray();
        }

        public int GetDimensionCount()
        {
            return columnCount * dataRows.Count;
        }

        public double[] GetIntervals()
        {
            return dataRows.Select(row => row.Item1).ToArray();
        }

        public double? GetDuration()
        {
            return duration;
        }

        public double[] GetAllValuesForColumns(int[] columns)
        {
            if (columns.Length <= 0)
            {
                return new double[0]; // nothing to return if no columns
            }
            return GetDataRows().SelectMany(row => row.Item2.Where((value, column) => columns.Contains(column))).ToArray(); // a flat array of values for all provided columns
        }

        public virtual T AcceptVisitor<T>(SampleVisitor<T> visitor) 
        {
            return visitor.Accept(this);
        }

        public void SaveAsCSV(String fileName)
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter(fileName);
            foreach (Tuple<double, double[]> row in GetDataRows())
            {
                string dataRow = String.Join(",", row.Item2);
                file.WriteLine(dataRow);
            }
            file.Close();
        }

    }

}
