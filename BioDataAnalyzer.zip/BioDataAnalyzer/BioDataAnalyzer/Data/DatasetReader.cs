﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using csmatio.io;
using csmatio.types;

namespace BioDataAnalyzer.Data
{
    public class DatasetReader
    {
        private SampleSet<Sample> dataSamples;
        private SampleExtractor[] extractors;
        private int order;

        public DatasetReader(params SampleExtractor[] extractors)
        {
            dataSamples = new SampleSet<Sample>();
            this.extractors = extractors;
            this.order = 0;
        }

        /**
         * sampleFile = path to sample file
         * identifier = unique identifier for this sample
         * startLine = line to start recording from (index at 0)
         * timeColumn = column of the time record indexed at 0 (to be ignored in data and recorded along side it), ignored by default
         * order = the order of this sample amongst its peers
         */
        public void AddDelimitedFileSample(string sampleFile, string identifier, string delimiter, int startLine = 0, int? order = null, int? timeColumn = null, double? interval = null, bool hasDuration = true)
        {
            if (startLine < 0)
            {
                throw new ArgumentException("startLine must be a value greater than 0");
            }
            ValidateDurationParameters(timeColumn, interval, hasDuration);
            StreamReader dataReader = new StreamReader(sampleFile);

            int i = 0;
            List<Tuple<double, double[]>> dataColumns = new List<Tuple<double, double[]>>();
            do 
            {
                string dataRow = dataReader.ReadLine();
                if (i >= startLine)
                {
                    string[] columnStrings = dataRow.Split(delimiter.ToCharArray()).Where(column => column.Length > 0).ToArray(); // ignore empty columns (i.e. the last column will typically be empty)
                    double[] columns = new double[!timeColumn.HasValue ? columnStrings.Length : columnStrings.Length - 1];
                    double time = interval.HasValue ? (i - startLine) * interval.Value : (i - startLine);
                    int k = 0;
                    for(int j = 0; j < columnStrings.Length; j++) 
                    {
                        if (columnStrings[j].Trim().Length <= 0)
                        {
                            continue;  // ignore white space
                        }

                        if (j != timeColumn)
                        {
                            columns[k++] = Int32.Parse(columnStrings[j]);
                        } 
                        else
                        {
                            time = Double.Parse(columnStrings[j]);
                        }
                    }
                    dataColumns.Add(new Tuple<double, double[]>(time, columns));
                }
                i++;
            } while(dataReader.Peek() != -1);
            dataSamples.Add(ExtractSample(new StandardSample(identifier, dataColumns, (order.HasValue ? order.Value : this.order), hasDuration)));
        }

        public void AddMatlabFileSample(String sampleFile, string identifier, string fieldName, int? order = null, int? timeColumn = null, double? interval = null, bool hasDuration = true)
        {
            ValidateDurationParameters(timeColumn, interval, hasDuration);

            // see https://sourceforge.net/p/csmatio/wiki/Usage%20Examples/
            MatFileReader matReader = new MatFileReader(sampleFile);
            MLDouble dataNode = (matReader.Content[fieldName] as MLDouble);
            // if we get here we know we have an int16 data type
            double[][] matDataColumns = dataNode.GetArray();
            List<Tuple<double, double[]>> dataColumns = new List<Tuple<double, double[]>>();
            for (int i = 0; i < matDataColumns.Length; i++)
            {
                double[] columns = new double[!timeColumn.HasValue ? matDataColumns[i].Length : matDataColumns[i].Length - 1];
                double time = interval.HasValue ? i * interval.Value : i;
                int k = 0;
                for (int j = 0; j < matDataColumns[i].Length; j++)
                {
                    if (j != timeColumn)
                    {
                        columns[k++] = matDataColumns[i][j];
                    }
                    else
                    {
                        time = matDataColumns[i][j];
                    }
                }
                dataColumns.Add(new Tuple<double, double[]>(time, columns));
            }
            dataSamples.Add(ExtractSample(new StandardSample(identifier, dataColumns, (order.HasValue ? order.Value : this.order), hasDuration)));
        }

        private void ValidateDurationParameters(int? timeColumn, double? intervalInSeconds, bool hasDuration)
        {
            if (timeColumn.HasValue && intervalInSeconds.HasValue)
            {
                throw new ArgumentException("Can only specify either a timeColumn or intervalInSeconds but not both");
            }
            if (!timeColumn.HasValue && !intervalInSeconds.HasValue && hasDuration)
            {
                throw new ArgumentException("Must set either a timeColumn or intervalInSeconds or explicitly mark this sample has having no duration");
            }
        }

        private Sample ExtractSample(Sample sample)
        {
            Sample extractedSample = sample;
            // if extractors are required the filter each sample using the extractor
            foreach (SampleExtractor extractor in extractors)
            {
                extractedSample = extractor.Extract(sample);
            }
            return extractedSample; // do nothing if no extractors to apply
        }

        /**
         * Get the raw sample set (with only applicable extractors if provided)
         */
        public SampleSet<Sample> GetSampleSet()
        {
            return dataSamples;
        }

    }
}
