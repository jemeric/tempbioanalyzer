﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class SampleSet<T> : List<T> where T : Sample 
    {
        private Preprocessor preprocessorHead;

        public SampleSet()
        {
            preprocessorHead = null;
        }

        protected SampleSet(Preprocessor preprocessorHead = null)
        {
            this.preprocessorHead = preprocessorHead;
        }

        public bool isCrossValidatedSet()
        {
            return this is CrossValidatedSample;
        }

        public SampleSet<T> ApplySampleExtractor(SampleExtractor extractor)
        {
            // return transformed sample set
            extractor.SetPredecessor(preprocessorHead); // set the current preprocessor as the predecessor to the newly applied one for initializing the new SampleSet
            SampleSet<T> extracted = new SampleSet<T>(extractor);
            foreach(Sample sample in this) 
            {
                extracted.Add((T)extractor.Extract(sample));
            }
            return extracted;
        }

        /**
         * Get a a subset of the raw sample set with a smaller grouping of extracted columns (i.e. a column for average, minimum contour, etc)
         */
        public SampleSet<T> GenerateSampleSubsets(params SubsetExtractor[] subsetExtractors)
        {
            if (subsetExtractors.Length < 1)
            {
                throw new ArgumentException("No subset extractors provided");
            }
            SampleSubsetExtractor subsetExtractor = new SampleSubsetExtractor(subsetExtractors);
            subsetExtractor.SetPredecessor(preprocessorHead); // set the current preprocessor as the predecessor to the newly applied one for initializing the new SampleSet
            SampleSet<T> subsets = new SampleSet<T>(subsetExtractor);
            foreach (Sample sample in this)
            {
                subsets.Add((T)subsetExtractor.Extract(sample));
            }
            return subsets;
        }

        public SampleSet<T> ApplyTransformation(SampleTransform transform)
        {
            transform.SetPredecessor(preprocessorHead); // set the current preprocessor as the predecessor to the newly applied one for initializing the new SampleSet
            SampleSet<T> transformedSampleSet = new SampleSet<T>(preprocessorHead);
            foreach (T sample in this)
            {
                transformedSampleSet.Add((T)transform.ApplyTransform(sample));
            }
            return transformedSampleSet;
        }

        public SampleSet<T> ApplyPreprocessor(Preprocessor preprocessor)
        {
            preprocessor.SetPredecessor(preprocessorHead); // set the current preprocessor as the predecessor to the newly applied one for initializing the new SampleSet
            SampleSet<T> preprocessedSampleSet = new SampleSet<T>(preprocessor);
            foreach (T sample in this)
            {
                preprocessedSampleSet.Add((T)preprocessor.Evaluate(sample));
            }
            return preprocessedSampleSet;
        }

        public Preprocessor GetPreprocessor()
        {
            return preprocessorHead; // all preprocessors applied in the generation of this sample set (use recursive GetPredecessor() to get back to head)
        }

        public List<Sample> AsSampleList()
        {
            return new List<Sample>(this.Cast<Sample>());
        }
    }
}
