﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class SampleGRFExtractor : SubsetExtractor
    {
        public List<double> Extract(Sample sample)
        {
            List<double[]> sampleGRF = new List<double[]>();
            double[] previousRow = Enumerable.Repeat(0.0, 88).ToArray();
            // get individual GRFs
            foreach (Tuple<double, double[]> sampleRow in sample.GetDataRows())
            {
                double[] GRF = sampleRow.Item2.Zip(previousRow, (x, y) => x + y).ToArray();
                sampleGRF.Add(GRF);
                previousRow = GRF;
            }
            // get global GRF
            List<double> globalGRFSubset = new List<double>();
            foreach (double[] GRF in sampleGRF)
            {
                globalGRFSubset.Add(Convert.ToInt32(GRF.Average()));
            }
            return globalGRFSubset;
        }


    }
}
