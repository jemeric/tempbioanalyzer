﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class SampleMaximumContourExtractor : SubsetExtractor
    {
        public List<double> Extract(Sample sample)
        {
            List<double> maximumContourSubset = new List<double>();
            foreach (Tuple<double, double[]> sampleRow in sample.GetDataRows())
            {
                maximumContourSubset.Add(sampleRow.Item2.Max());
            }
            return maximumContourSubset;
        }
    }
}
