﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BioDataAnalyzer.Data
{
    public class SampleSubsetExtractor : Preprocessor
    {
        private SubsetExtractor[] subsetExtractors;

        public SampleSubsetExtractor(params SubsetExtractor[] subsetExtractors)
        {
            this.subsetExtractors = subsetExtractors;
        }

        public Sample Extract(Sample sample)
        {
            return SubsetGenerator.GenerateFromSample(sample).ApplyExtractors(subsetExtractors).GetSubset();
        }

        protected override Sample Process(Sample sample)
        {
            return Extract(sample);
        }

        public override Preprocessor Copy()
        {
            return new SampleSubsetExtractor(subsetExtractors);
        }
    }
}
