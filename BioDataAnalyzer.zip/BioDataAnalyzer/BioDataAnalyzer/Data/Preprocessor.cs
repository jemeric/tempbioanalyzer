﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;

namespace BioDataAnalyzer.Data
{
    public abstract class Preprocessor
    {
        private Preprocessor predecessor;

        public Preprocessor()
        {
            predecessor = null;
        }

        public Sample Evaluate(Sample sample)
        {
            if (GetPredecessor() != null)
            {
                return Process(GetPredecessor().Process(sample)); // evaluate the predecessor preprocessor before evaluating this
            }
            else
            {
                return Process(sample); // no predecessor preprocessor so evaluate the sample directly
            }
        }

        public void SetPredecessor(Preprocessor predecessor)
        {
            this.predecessor = predecessor;
        }

        public Preprocessor GetPredecessor()
        {
            return predecessor;
        }

        protected abstract Sample Process(Sample sample);
    }
}
