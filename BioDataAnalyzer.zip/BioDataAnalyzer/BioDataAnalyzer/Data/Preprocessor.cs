﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;

namespace BioDataAnalyzer.Data
{
    public abstract class Preprocessor
    {
        private Preprocessor predecessor;

        public Preprocessor()
        {
            predecessor = null;
        }

        public Sample Evaluate(Sample sample)
        {
            if (GetPredecessor() != null)
            {
                return Process(GetPredecessor().Process(sample)); // evaluate the predecessor preprocessor before evaluating this
            }
            else
            {
                return Process(sample); // no predecessor preprocessor so evaluate the sample directly
            }
        }

        public Preprocessor SetPredecessor(Preprocessor predecessor)
        {
            this.predecessor = predecessor;
            return this;
        }

        public Preprocessor GetPredecessor()
        {
            return predecessor;
        }

        protected abstract Sample Process(Sample sample);

        public abstract Preprocessor Copy();
    }
}
