﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;
using BioDataAnalyzer.Classification;
using BioDataAnalyzer.Utilities.Helpers;
using System.Threading.Tasks;

/**
 * Tools to evaluate biometric classifiers against sample sets
 * 
 */
namespace BioDataAnalyzer.Evaluation
{
    // for tracking individual FAR / FRR pairs that would be recovered during cross validation
    public class ErrorRatePair
    {
        private int falseAcceptedCount;
        private int totalAcceptedTestCount;
        private int falseRejectedCount;
        private int totalRejectedTestCount;

        public ErrorRatePair(int falseAcceptedCount, int totalAcceptedTestCount, int falseRejectedCount, int totalRejectedTestCount)
        {
            this.falseAcceptedCount = falseAcceptedCount;
            this.totalAcceptedTestCount = totalAcceptedTestCount;
            this.falseRejectedCount = falseRejectedCount;
            this.totalRejectedTestCount = totalRejectedTestCount;
        }

        private int getFalseAcceptedCount()
        {
            return falseAcceptedCount;
        }

        private int getTotalAcceptedTestCount()
        {
            return totalAcceptedTestCount;
        }

        private int getFalseRejectedCount()
        {
            return falseRejectedCount;
        }

        private int getTotalRejectedTestCount()
        {
            return totalRejectedTestCount;
        }

        public double getFAR()
        {
            return (double)falseAcceptedCount / (double)totalAcceptedTestCount;
        }

        public double getFRR()
        {
            return (double)falseRejectedCount / (double)totalRejectedTestCount;
        }

        public double getErrorDelta()
        {
            return getFAR() - getFRR();
        }

        public static ErrorRatePair operator +(ErrorRatePair e1, ErrorRatePair e2)
        {
            return new ErrorRatePair(e1.getFalseAcceptedCount() + e2.getFalseAcceptedCount(), e1.getTotalAcceptedTestCount() + e2.getTotalAcceptedTestCount(), e1.getFalseRejectedCount() + e2.getFalseRejectedCount(), e1.getTotalRejectedTestCount() + e2.getTotalRejectedTestCount());
        }
    }

    // for tracking the result of a biometric analysis
    public class BiometricResult 
    {
        private double ERR; // the total cross validated EER
        private List<ErrorRatePair> errorRates; // the FAR / FRR for each cross validation
        public BiometricResult(double ERR, List<ErrorRatePair> errorRates)
        {
            this.ERR = ERR;
            this.errorRates = errorRates;
        }

        public double getERR()
        {
            return ERR;
        }

        public List<ErrorRatePair> getErrorRates()
        {
            return errorRates;
        }
    }

    public class Evaluator
    {

        public static readonly double DEFAULT_MIN_INTERVAL = 0.01;

        public static BiometricResult Evaluate<T>(SampleSet<T> sampleSet, Classifier classifier, int trainingSize) where T : Sample
        {
            return Evaluate(sampleSet, classifier, trainingSize, DEFAULT_MIN_INTERVAL, 0, ListHelper.CountIdentifiers(sampleSet));
        }

        public static BiometricResult Evaluate<T>(SampleSet<T> sampleSet, Classifier classifier, int trainingSize, double minInterval) where T : Sample
        {
            return Evaluate(sampleSet, classifier, trainingSize, minInterval, 0, ListHelper.CountIdentifiers(sampleSet));
        }

        public static BiometricResult Evaluate<T>(SampleSet<T> sampleSet, Classifier classifier, int trainingSize, int xValidationStart, int xValidationLength) where T : Sample
        {
            return Evaluate(sampleSet, classifier, trainingSize, DEFAULT_MIN_INTERVAL, xValidationStart, xValidationLength);
        }

        // perform cross validated EER evaluation
        public static BiometricResult Evaluate<T>(SampleSet<T> sampleSet, Classifier classifier, int trainingSize, double minInterval, int xValidationStart, int xValidationLength) where T : Sample
        {
            if (minInterval >= 0.5 || minInterval <= 0)
            {
                throw new ArgumentException("Invalid Min Interval: must be a number between 0 and 0.5");
            }

            // sort dataset into cross validations and train classifiers asynchronously - we need to do this before we start to recurse to avoid repetitive classifier training
            object localLockObject = new object();
            Dictionary<int, ClassifierInstance> xClassifierInstances = new Dictionary<int, ClassifierInstance>();
            Parallel.For<Dictionary<int, ClassifierInstance>>(xValidationStart, (xValidationStart + xValidationLength), () => new Dictionary<int, ClassifierInstance>(), (x, loop, classifierInstances) =>
                {
                    List<Sample> samples = GetSampleSetTrainingSamples(sampleSet, trainingSize, x);
                    classifierInstances.Add(x, classifier.getInstance(samples));
                    return classifierInstances;
                },
                (x) => { lock (localLockObject) xClassifierInstances = new Dictionary<int, ClassifierInstance>(x); });

            return Evaluate(sampleSet, xClassifierInstances, trainingSize, minInterval, 0.5, new BiometricResult(0.5, null), xValidationStart, xValidationLength);
        }

        private static BiometricResult Evaluate<T>(SampleSet<T> sampleSet, Dictionary<int, ClassifierInstance> xClassifierInstances, int trainingSize, double minInterval, double interval, BiometricResult threshold, int xValidationStart, int xValidationLength) where T : Sample
        {
            if (interval < minInterval)
            {
                // the threshold found for the smallest interval represents the best guess at the EER
                return threshold;
            }
            else
            {
                // recurse until the smallest allowable interval is found
                Tuple<ErrorRatePair, List<ErrorRatePair>> delta1 = CalculateErrorRate(sampleSet, xClassifierInstances, trainingSize, (threshold.getERR() - (interval / 2.0)), xValidationStart, xValidationLength);
                Tuple<ErrorRatePair, List<ErrorRatePair>> delta2 = CalculateErrorRate(sampleSet, xClassifierInstances, trainingSize, (threshold.getERR() - (interval / 2.0)), xValidationStart, xValidationLength);

                if (delta1.Item1.getErrorDelta() < delta2.Item1.getErrorDelta())
                {
                    return Evaluate(sampleSet, xClassifierInstances, trainingSize, minInterval, (interval / 2.0), new BiometricResult((threshold.getERR() - (interval / 2.0)), delta1.Item2), xValidationStart, xValidationLength);
                }
                else
                {
                    return Evaluate(sampleSet, xClassifierInstances, trainingSize, minInterval, (interval / 2.0), new BiometricResult((threshold.getERR() + (interval / 2.0)), delta2.Item2), xValidationStart, xValidationLength);
                }
            }
        }

        public static BiometricResult Evaluate(ClassifierInstance classifier, List<Sample> testingSamples)
        {
            return Evaluate(classifier, testingSamples, DEFAULT_MIN_INTERVAL);
        }

        // perform EER evaluation on provided testing samples
        public static BiometricResult Evaluate(ClassifierInstance classifier, List<Sample> testingSamples, double minInterval)
        {
            return Evaluate(classifier, testingSamples, minInterval, 0.5, new BiometricResult(0.5, null));
        }

        private static BiometricResult Evaluate(ClassifierInstance classifier, List<Sample> testingSamples, double minInterval, double interval, BiometricResult threshold)
        {
            if (interval < minInterval)
            {
                // the threshold found for the smallest interval represents the best guess at the EER
                return threshold;
            }
            else
            {
                // recurse until the smallest allowable interval is hit
                ErrorRatePair delta1 = CalculateErrorRate(classifier, testingSamples, (threshold.getERR() - (interval / 2.0)));
                ErrorRatePair delta2 = CalculateErrorRate(classifier, testingSamples, (threshold.getERR() + (interval / 2.0)));

                if (delta1.getErrorDelta() < delta2.getErrorDelta())
                {
                    return Evaluate(classifier, testingSamples, minInterval, (interval / 2.0), new BiometricResult((threshold.getERR() - (interval / 2.0)), new List<ErrorRatePair> { delta1 }));
                }
                else
                {
                    return Evaluate(classifier, testingSamples, minInterval, (interval / 2.0), new BiometricResult((threshold.getERR() + (interval / 2.0)), new List<ErrorRatePair> { delta2 }));
                }
            }
        }

        private static Tuple<ErrorRatePair, List<ErrorRatePair>> CalculateErrorRate<T>(SampleSet<T> sampleSet, Dictionary<int, ClassifierInstance> xClassifierInstances, int trainingSize, double threshold, int xValidationStart, int xValidationLength) where T : Sample
        {
            // test classifier instances with testing samples and threshold asynchronously to get cross validated result
            object localLockObject = new object();
            List<ErrorRatePair> errorRates = new List<ErrorRatePair>();
            Parallel.For<List<ErrorRatePair>>(xValidationStart, (xValidationStart + xValidationLength), () => new List<ErrorRatePair>(), (x, loop, errorRatePairs) =>
                {
                    List<Sample> samples = GetSampleSetTestingSamples(sampleSet, trainingSize, x);
                    errorRatePairs.Add(CalculateErrorRate(xClassifierInstances[x], samples, threshold));
                    return errorRatePairs;
                },
                (x) => { lock (localLockObject) errorRates.AddRange(x); });

            ErrorRatePair totalError = errorRates[0];
            for (int i = 1; i < errorRates.Count; i++)
            {
                totalError = totalError + errorRates[i];
            }
            return new Tuple<ErrorRatePair, List<ErrorRatePair>>(totalError, errorRates);
        }

        private static List<Sample> GetSampleSetTrainingSamples<T>(SampleSet<T> sampleSet, int trainingSize, int x) where T : Sample
        {
            if (sampleSet.isCrossValidatedSet())
            {
                // if the list is cross validated then filter out this cross validation
                return GetTrainingSamples(ListHelper.GetCrossValidation(sampleSet.Cast<CrossValidatedSample>().ToList(), x), trainingSize, x);
            }
            else
            {
                // if the list is not cross validated then use it directly
                return GetTrainingSamples(sampleSet.AsSampleList(), trainingSize, x);
            }
        }

        private static List<Sample> GetTrainingSamples(List<Sample> sampleSet, int trainingSize, int x)
        {
            List<String> identifiers = ListHelper.GetIdentifiers(sampleSet);
            List<Sample> trainingSamples = new List<Sample>();

            foreach(String identifier in identifiers) 
            {
                List<Sample> identifierSamples = ListHelper.GetSamplesWithIdentifier(sampleSet, identifier);
                if (trainingSize >= identifierSamples.Count)
                {
                    throw new ArgumentException("Sample with identifier " + identifier + " contains fewer samples than the allowable training size");
                }
                // get all samples for each identifier within the provided training cross validation range
                for(int k = 0; k < trainingSize; k++) 
                {
                    trainingSamples.Add(identifierSamples[(k + x) % identifierSamples.Count]);
                }
            }
            return trainingSamples;
        }

        private static List<Sample> GetSampleSetTestingSamples<T>(SampleSet<T> sampleSet, int trainingSize, int x) where T : Sample
        {
            if (sampleSet.isCrossValidatedSet())
            {
                // if the list is cross validated then filter out this cross validation
                return GetTestingSamples(ListHelper.GetCrossValidation(sampleSet.Cast<CrossValidatedSample>().ToList(), x), trainingSize, x);
            }
            else
            {
                // if the list is not cross validated then use it directly
                return GetTestingSamples(sampleSet.AsSampleList(), trainingSize, x);
            }
        }

        private static List<Sample> GetTestingSamples(List<Sample> sampleSet, int trainingSize, int x)
        {
            List<String> identifiers = ListHelper.GetIdentifiers(sampleSet);
            List<Sample> testingSamples = new List<Sample>();

            foreach (String identifier in identifiers)
            {
                List<Sample> identifierSamples = ListHelper.GetSamplesWithIdentifier(sampleSet, identifier);
                // get all samples for each identifier within the provided testing cross validation range
                for (int k = trainingSize; k <= identifierSamples.Count; k++)
                {
                    testingSamples.Add(identifierSamples[(k + x) % identifierSamples.Count]);
                }
            }
            return testingSamples;
        }

        public static ErrorRatePair CalculateErrorRate(ClassifierInstance classifier, List<Sample> testingSamples, double threshold) 
        {
            Tuple<int, int> farResults = CalculateFAR(classifier, testingSamples, threshold);
            Tuple<int, int> frrResults = CalculateFRR(classifier, testingSamples, threshold);
            return new ErrorRatePair(farResults.Item1, farResults.Item2, frrResults.Item1, frrResults.Item2);
        }

        private static Tuple<int, int> CalculateFAR(ClassifierInstance classifier, List<Sample> testingSamples, double threshold)
        {
            int accepted = 0;
            int rejected = 0;
            List<String> identifiers = ListHelper.GetIdentifiers(testingSamples);
            // for each identifier find the samples that correctly match the identifier given the threshold
            foreach (String identifier in identifiers)
            {
                // TODO - there may be benefits to be gained by doing this in parallel
                foreach (Sample sample in testingSamples)
                {
                    if (!sample.GetIdentifier().Equals(identifier))
                    {
                        if (classifier.Verify(sample, identifier) > threshold)
                        {
                            accepted++; // falsely accepted sample for a different identifier
                        }
                        else
                        {
                            rejected++; // correctly rejected sample for a different identifier
                        }
                    }
                }
            }
            return new Tuple<int, int>(accepted, (accepted + rejected));
        }

        private static Tuple<int, int> CalculateFRR(ClassifierInstance classifier, List<Sample> testingSamples, double threshold)
        {
            int accepted = 0;
            int rejected = 0;
            List<String> identifiers = ListHelper.GetIdentifiers(testingSamples);
            // for each identifier find the samples taht incorrectly match the identifier given the threshold
            foreach (String identifier in identifiers)
            {
                // TODO - there may be benefits to be gained by doing this in parallel
                foreach (Sample sample in testingSamples)
                {
                    if (sample.GetIdentifier().Equals(identifier))
                    {
                        if (classifier.Verify(sample, identifier) <= threshold)
                        {
                            rejected++; // falsely rejected sample for the correct identifier
                        }
                        else
                        {
                            accepted++; // correctly accepted sample for the identifier
                        }
                    }
                }
            }
            return new Tuple<int, int>(rejected, (accepted + rejected));
        }

    }
}
