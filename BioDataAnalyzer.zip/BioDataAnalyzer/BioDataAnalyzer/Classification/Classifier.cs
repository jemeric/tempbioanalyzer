﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;

namespace BioDataAnalyzer.Classification
{
    public interface ClassifierInstance
    {
        double Verify(Sample sample, string identifier);
    }

    public interface Classifier
    {

        ClassifierInstance getInstance(List<Sample> trainingSamples);

    }
}
