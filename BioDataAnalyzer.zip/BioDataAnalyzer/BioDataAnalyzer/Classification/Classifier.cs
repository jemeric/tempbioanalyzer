﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BioDataAnalyzer.Data;
using BioDataAnalyzer.Utilities.Helpers;

namespace BioDataAnalyzer.Classification
{
    public abstract class ClassifierFactory<T> where T : Sample
    {
        protected Dictionary<int, ClassifierInstance> xClassifierInstances = null;
        protected double standardMin;
        protected double standardMax;

        public ClassifierFactory(double standardMin, double standardMax)
        {
            this.standardMin = standardMin;
            this.standardMax = standardMax;
        }

        public ClassifierFactory<T> Train(List<Sample> trainingSamples)
        {
            // train against all provided samples (i.e. none of these are needed for verification)
            xClassifierInstances = new Dictionary<int, ClassifierInstance>();
            xClassifierInstances.Add(0, CreateInstance(trainingSamples.Cast<Sample>().ToList(), standardMin, standardMax));
            return this;
        }

        public ClassifierFactory<T> Train(SampleSet<T> trainingSamples, int trainingSize, int xValidationStart = 0, int xValidationLength = 1)
        {
            // train with a dataset that may require additional cross validation classifier instances
            xClassifierInstances = Enumerable.Range(xValidationStart, xValidationLength).AsParallel().Select(x => new { x, instance = CreateInstance(SampleSetHelpers.GetSampleSetTrainingSamples(trainingSamples, trainingSize, x), standardMin, standardMax) })
                .ToDictionary(validation => validation.x, validation => validation.instance);
            return this;
        }

        public bool IsTrained()
        {
            return xClassifierInstances != null;
        }

        public ClassifierInstance CreateInstance(List<Sample> trainingSamples, double standardMin, double standardMax)
        {
            // generate scaling/shift per feature to acheive a standard min/max for the training data
            double range = standardMax - standardMin;
            double[] featureMin = SampleSetHelpers.GetMinimumFeatureValues(trainingSamples);
            double[] featureMax = SampleSetHelpers.GetMaximumFeatureValues(trainingSamples);

            double[] featureScaling = featureMax.Select((max, i) => range / (max - featureMin[i])).ToArray();
            double[] featureShift = featureScaling.Select((scale, i) => standardMin - (featureMin[i] * scale)).ToArray();

            // apply scaling/shift to the features in each training sample
            List<Sample> standardizedSamples = trainingSamples.Select(sample => sample.AcceptVisitor(
                new SampleDimensionVisitor(StandardizationHelper.GenerateTransformedData(sample.GetDimensions(), (value, i) => (value * featureScaling[i]) + featureShift[i])))).ToList();

            return CreateInstance(standardizedSamples, featureScaling, featureShift);
        }

        public abstract ClassifierInstance CreateInstance(List<Sample> trainingSamples, double[] featureScaling, double[] featureShift);
 
        public ClassifierInstance getInstance(int crossValidation = 0)
        {
            if (!IsTrained() || !xClassifierInstances.ContainsKey(crossValidation))
            {
                throw new ArgumentException("Attempted cross validation " + crossValidation + " that has not been trained");
            }
            return xClassifierInstances[crossValidation];
        }
    }

    public class ClassifierInstance
    {
        protected Classifier classifier;
        protected double[] featureScaling;
        protected double[] featureShift;

        public ClassifierInstance(Classifier classifier, double[] featureScaling, double[] featureShift)
        {
            this.classifier = classifier;
            this.featureScaling = featureScaling;
            this.featureShift = featureShift;
        }

        public double Verify(double[] features, string identifier)
        {
            // scale/shift features to fit within standard range
            double[] standardizedFeatures = StandardizationHelper.GenerateTransformedData(features, (value, i) => (value * featureScaling[i]) + featureShift[i]);
            return classifier.Verify(standardizedFeatures, identifier);
        }
    }

    public interface Classifier
    {
        double Verify(double[] features, string identifier);
    }

}
